#!/bin/sh

rm -fr /data/local/tmp/plugin/bin/vpkd
rm -fr /data/local/tmp/plugin/bin/vpick
rm -fr /data/local/tmp/plugin/etc/init/init.vpick.rc
rm -fr /data/local/tmp/plugin/meta/vpk