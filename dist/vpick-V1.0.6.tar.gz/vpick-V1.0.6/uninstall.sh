#!/bin/sh

stop vpkd
rm -fr /data/local/tmp/plugin/bin/vpkd
rm -fr /data/local/tmp/plugin/bin/vpick
rm -fr /data/local/tmp/plugin/etc/init/init.vpkd.rc
rm -fr /data/local/tmp/plugin/meta/vpk